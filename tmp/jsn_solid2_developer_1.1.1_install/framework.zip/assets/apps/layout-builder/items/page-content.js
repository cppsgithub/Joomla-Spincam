{
 "class": "page-content",
 "rows": [
 {
 "cols": [
 {
 "class": "col-xs-12",
 "settings": {
 "show_on_front_page": {
 "type": "checkbox",
 "label": "show-on-front-page",
 "value": "1",
 "default": "1"
 }
 }
 }
 ]
 }
 ],
 "one-time-item": true
}
