{
	"class": "form-horizontal",
	"rows": [
		{
			"class": "margin-top-right",
			"cols": [
				{
					"class": "col-xs-12",
					"settings": {
						"html": {
							"type": "tinymce-editor",
							"label": "Html"
						}
					}
				},
				{
					"class": "col-xs-6",
					"settings": {
						"prefix-class": {
							"type": "text",
							"label": "Prefix Class"
						}
					}
				}
			]
		}
	]
}
