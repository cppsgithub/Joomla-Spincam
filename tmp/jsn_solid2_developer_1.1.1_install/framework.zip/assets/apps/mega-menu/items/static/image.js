{
	"class": "form-horizontal",
	"rows": [
		{
			"class": "form-group",
			"cols": [
				{
					"class": "col-sm-12",
					"settings": {
						"image": {
							"type": "choose-image",
							"label": "image"
						}
					}
				},				
				{
					"class": "col-sm-12",
					"settings": {
						"alt": {
							"type": "text",
							"label": "alt-text"
						}
					}
				},
				{
					"class": "col-sm-12",
					"settings": {
						"prefix-class": {
							"type": "text",
							"label": "prefix-class"
						}
					}
				}
			]
		}
	]
}
