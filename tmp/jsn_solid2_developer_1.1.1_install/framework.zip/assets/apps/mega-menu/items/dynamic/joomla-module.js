{
	"class": "form-horizontal",
	"rows": [
		{
			"class": "margin-top-right",
			"cols": [
				{
					"class": "col-xs-12",
					"settings": {
						"module": {
							"type": "module-picker",
							"label": "Module"
						}
					}
				},
				{
					"class": "col-xs-12",
					"settings": {
						"style": {
							"type": "module-style",
							"label": "Style"
						}
					}
				}
			]
		}
	]
}
