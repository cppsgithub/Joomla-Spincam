{
	"class": "form-horizontal",
	"rows": [
		{
			"class": "margin-top-right",
			"cols": [
				{
					"class": "col-xs-12",
					"settings": {
						"module-position": {
							"type": "module-position",
							"label": "position"
						}
					}
				}
				
			]
		}
	]
}