{
 "class": "content-settings",
 "rows": [
 {
 "cols": [
 {
 "class": "col-xs-12",
 "settings": {
 "color": {
 "type": "color-picker",
 "label": "color"
 }
 }
 },
 {
 "class": "col-xs-12",
 "settings": {
 "font-size": {
 "type": "slider",
 "label": "font-size",
 "min": 0,
 "max": 50,
 "step": 1,
 "default": "",
 "suffix": "px"
 }
 }
 }
 ]
 }
 ]
}
