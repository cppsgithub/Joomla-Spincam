{
 "class": "heading-settings",
 "rows": [
 {
 "cols": [
 {
 "class": "col-xs-12",
 "settings": {
 "main-color": {
 "type": "color-picker",
 "label": "main-color",
 "default": "#E70200",
 "custom_only": true
 }
 }
 },
 {
 "class": "col-xs-12",
 "settings": {
 "sub-color": {
 "type": "color-picker",
 "label": "sub-color",
 "default": "#F86201",
 "custom_only": true
 }
 }
 }
 ]
 }
 ]
}
