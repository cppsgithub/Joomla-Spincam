{
 "class": "link-settings",
 "rows": [
 {
 "cols": [
 {
 "class": "col-xs-12",
 "settings": {
 "link-color": {
 "type": "color-picker",
 "label": "normal-color"
 }
 }
 },
 {
 "class": "col-xs-12",
 "settings": {
 "link-hover-color": {
 "type": "color-picker",
 "label": "hover-color"
 }
 }
 }
 ]
 }
 ]
}
