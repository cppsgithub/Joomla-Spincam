{
 "class": "inner-page-settings",
 "rows": [
 {
 "cols": [
 {
 "class": "col-xs-12",
 "settings": {
 "inner-background-color": {
 "type": "color-picker",
 "label": "background-color"
 }
 }
 },
 {
 "class": "col-xs-12",
 "settings": {
 "inner-border": {
 "type": "border-settings",
 "label": "border"
 }
 }
 },
 {
 "class": "col-xs-12",
 "settings": {
 "inner-box-shadow": {
 "type": "box-shadow-settings",
 "label": "box-shadow"
 }
 }
 }
 ]
 }
 ]
}