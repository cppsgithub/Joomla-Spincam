{
 "class": "custom-html",
 "rows": [
 {
 "class": "separator-after",
 "cols": [
 {
 "class": "col-xs-12",
 "settings": {
 "name": {
 "type": "text",
 "label": "name"
 }
 }
 }
 ]
 },
 {
 "cols": [
 {
 "class": "col-xs-12",
 "settings": {
 "html": {
 "type": "editor",
 "label": "html-content"
 }
 }
 }
 ]
 },
 {
 "class": "separator-before",
 "cols": [
 {
 "class": "col-xs-12",
 "settings": {
 "class": {
 "type": "text",
 "label": "custom-classes"
 }
 }
 }
 ]
 }
 ]
}
