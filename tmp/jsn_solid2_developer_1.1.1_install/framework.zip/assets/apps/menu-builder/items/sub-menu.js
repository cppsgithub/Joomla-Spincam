{
 "class": "menu",
 "rows": [
 {
 "cols": [
 {
 "class": "col-xs-12",
 "settings": {
 "name": {
 "type": "text",
 "label": "name"
 }
 }
 }
 ]
 }
 ]
}
