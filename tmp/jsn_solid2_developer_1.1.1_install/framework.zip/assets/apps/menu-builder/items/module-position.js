{
 "class": "module-position",
 "rows": [
 {
 "class": "separator-after",
 "cols": [
 {
 "class": "col-xs-12",
 "settings": {
 "name": {
 "type": "text",
 "label": "name"
 }
 }
 }
 ]
 },
 {
 "cols": [
 {
 "class": "col-xs-12",
 "settings": {
 "module-position": {
 "type": "module-position",
 "label": "position"
 }
 }
 }
 ]
 },
 {
 "class": "separator-before",
 "cols": [
 {
 "class": "col-xs-12",
 "settings": {
 "class": {
 "type": "text",
 "label": "custom-classes"
 }
 }
 }
 ]
 }
 ]
}
