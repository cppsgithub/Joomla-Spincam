{
 "class": "joomla-module",
 "rows": [
 {
 "class": "separator-after",
 "cols": [
 {
 "class": "col-xs-12",
 "settings": {
 "name": {
 "type": "text",
 "label": "name"
 }
 }
 }
 ]
 },
 {
 "cols": [
 {
 "class": "col-xs-12",
 "settings": {
 "module": {
 "type": "module-picker",
 "label": "module"
 }
 }
 }
 ]
 },
 {
 "class": "separator-before",
 "cols": [
 {
 "class": "col-xs-12",
 "settings": {
 "class": {
 "type": "text",
 "label": "custom-classes"
 }
 }
 }
 ]
 }
 ]
}
