ALTER TABLE `#__jsn_uniform_forms` ADD `form_view_submission` int(11) NOT NULL DEFAULT 0;
ALTER TABLE `#__jsn_uniform_forms` ADD `form_view_submission_access` int(11) NOT NULL DEFAULT 0;