ALTER TABLE `#__jsn_uniform_forms` ADD `form_ajax_upload` tinyint(1) unsigned NOT NULL DEFAULT '0';
